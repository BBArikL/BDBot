---
name: Documentation change
about: You have an issue with the bot documentation?
title: New bot documentation issue
labels: documentation
assignees: ''

---


