---
name: Comic request
about: Suggest a comic for this project
title: New Comic request
labels: enhancement
assignees: ''

---

**Is your comic request on GoComics? If yes, please add a link.**
Example: Add garfield, comic page https://www.gocomics.com/garfield

**If it is not on GoComics, can you tell us more about the organization of the website? (Optional)**
A clear and concise description of the site.

**Anything else to add? (If the comic has alt-text, etc...)**
A clear and concise description.

**Additional context**
Add any other context or screenshots about the feature request here.
